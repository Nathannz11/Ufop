//Nathann Zini dos Reis 19.2.4007 BCC201-31
#include "biblioteca.h"

//Função para verificar se os arquivos foram indormados na ordem certa ao retomar um jogo salvo
void verificarArquivoDeEntrada(int argc, char *argv[]){
  int tamanho, j = 0;
  char extensao[10];
  tamanho = strlen(argv[1]);
  //Salva os 5 ultimos caracteres do arquivo numa variável
  for(int i = tamanho - 5; i < tamanho; i++ ){
    extensao[j] = argv[1][i];
    j++;
  }
  extensao[j] = '\0';
  //Compara a variável com os ultimos 5 caracteres e compara com ".jogo"
  if(strcmp(".jogo", extensao)){
    printf("Favor informar o arquivo com a extensao '.jogo' primeiro\n" );
    exit(0);
  }

}

//Função para fazer a alocação dinâmica da matriz
char** alocarMatriz(int l, int c){
  char** temp = malloc (l * sizeof(char*));
  for(int i  = 0; i < l; i++){
    temp[i] = malloc(c * sizeof(char));
  }
  return temp;
}

//Função para liberar a memória alocada para a matriz
void liberarMemoria(Jogo *jogo){
  for(int i  = 0; i < jogo->linha; i++){
    free(jogo->matrizEntrada[i]);
    free(jogo->tabuleiro[i]);
  }
  free(jogo->matrizEntrada);
  free(jogo->tabuleiro);
}

//Função que lê a matriz de um arquivo de entrada e a dimensão
void lerMatriz(FILE *arq, Jogo* jogo){
  //Lendo linha e coluna da matriz
  fscanf(arq,"%d %d", &jogo->linha, &jogo->coluna);

  //Chama a função para alocar a matriz
  jogo->matrizEntrada = alocarMatriz(jogo->linha, jogo->coluna);

  //Lê o arquivo para dentro da matriz enquanto não for o fim do arquivo
  do{
    for(int i = 0; i < jogo->linha; i++){
      for(int j = 0; j < jogo->coluna; j++){
        fscanf(arq, " ");
        fscanf(arq, "%c", &jogo->matrizEntrada[i][j]);
      }
    }
  }while(!feof(arq));
}

//Função que gera a matriz aleatoria (preenchida com os numeros e bombas)
void gerarMatriz(Jogo* jogo){
  //Chama a função para alocar a matriz dinamicamente
  jogo->matrizEntrada = alocarMatriz(jogo->linha, jogo->coluna);
  //Cria uma semente para gerar as bombas em posições aleatorias
  srand(time(NULL));
  //Inicializa a matriz com '0'
  for(int i  = 0; i < jogo->linha; i++){
    for(int j = 0; j < jogo->coluna; j++){
      jogo->matrizEntrada[i][j] = '0';
    }
  }
  //Variáveis que receberão qual posição será colocado uma bomba
  int l, c;
  //Faz um for para rodar 20% de vezes o tamanho da matriz (para ter 20% de bombas no campo)
  for(int i  = 0; i < jogo->linha*jogo->coluna / 5; i++){
    //recebe aleatoriamente a posição em que vai ser colocada a bomba
    l = rand() % jogo->linha;
    c = rand() % jogo->coluna;
    //Verifica se a posição selecionada já não foi preenchida com bomba
    if(jogo->matrizEntrada[l][c] == '0')
      jogo->matrizEntrada[l][c] = 'x';
    //Caso a posição selecionada fosse uma bomba, decremente o i para rodar o mesmo loop novamente para preencher 20% do campo com bombas
    else
      i--;
  }

  //Os dois primeiros for são para percorrer a matriz inteira
  for(int i  = 0; i < jogo->linha; i++){
    for(int j = 0; j< jogo->coluna; j++){
      //Verifica se a posição não é uma bomba para analisar as adjacentes para contar a quantidade de bomba e somar ao conteudo desta posição
      if(jogo->matrizEntrada[i][j] == '0'){
        //Dois for para percorrer as céllulas adjancentes para verificar se é bomba
        for(int k =  i - 1; k <= i + 1; k++){
          for(int m = j - 1; m <= j + 1; m++){
            //Condição para verificar se a posição está dentro do liminte da matriz, (se não estiver, não verifica a posição e pula pra proxima)
            if((k >= 0 && k < jogo->linha) && (m >= 0 && m < jogo->coluna)){
                //Verifica se tem uma bomba nessa posição
                if(jogo->matrizEntrada[k][m] == 'x')
                  //Soma 1 ao valor da posição que está sendo verificada
                  jogo->matrizEntrada[i][j]++;
              }
          }
        }
      }
    }
  }
}

//Função que exibe o menu de opções para o jogador
void menuDeOpcoes(){
  printf(BOLD("\t\t\t\t    _comando__argumento___________________descrição__________________\n"));
  printf(BOLD("\t\t\t\t   | x       |   'AB'  | Seleciona uma célula para marcar como bomba |\n"));
  printf(BOLD("\t\t\t\t   |_________|_________|_____________________________________________|\n"));
  printf(BOLD("\t\t\t\t   | o       |   'AB'  | Seleciona uma célula para ser aberta        |\n"));
  printf(BOLD("\t\t\t\t   |_________|_________|_____________________________________________|\n"));
  printf(BOLD("\t\t\t\t   | resolver|         | Resolve o jogo e o finaliza                 |\n"));
  printf(BOLD("\t\t\t\t   |_________|_________|_____________________________________________|\n"));
  printf(BOLD("\t\t\t\t   | salvar  |         | Salva o jogo em um arquivo 'out.txt'        |\n"));
  printf(BOLD("\t\t\t\t   |_________|_________|_____________________________________________|\n"));
  printf(BOLD("\t\t\t\t   | sair    |         | Sai do jogo sem salvá-lo                    |\n"));
  printf(BOLD("\t\t\t\t   |_________|_________|_____________________________________________|\n"));
  printf("\n\n");
}

//Função que exibe uma mensagem de derrota quando o jogador perde o jogo
void menuDerrota(){
    printf(BOLD("\t\t---------      -------------  -----------       -----------              --         --------------  ---------\n"));
    printf(BOLD("\t\t--     ----    --  ---------  --       ----     --       ----        --      --     ------  ------  --     --\n"));
    printf(BOLD("\t\t--      ----   --  --         --          --    --          --     --          --        -  -       --     --\n"));
    printf(BOLD("\t\t--       ----  --  ---------  --       ----     --       ----     --            --       -  -       --     --\n"));
    printf(BOLD("\t\t--       ----  --  ---------  --  ------        --  ------        --            --       -  -       -- --- --\n"));
    printf(BOLD("\t\t--      ----   --  --         --     ----       --     ----        --          --        -  -       -- - - --\n"));
    printf(BOLD("\t\t--     ----    --  ---------  --        ----    --        ----       --      --          -  -       -- - - --\n"));
    printf(BOLD("\t\t---------      -------------  --          ----  --          ----         --              ----       ---- ----\n\n\n"));
}

//Função que exibe uma mensagem de derrota quando o jogador ganha o jogo
void menuVitoria(){
  printf(BOLD("\t\t\t\t--           --  -----  --------------         --         -----------       -----  ---------\n"));
  printf(BOLD("\t\t\t\t --         --   -- --  ------  ------    --        --    --       ----     -- --  --     --\n"));
  printf(BOLD("\t\t\t\t  --       --    -- --       -  -       --            --  --          --    -- --  --     --\n"));
  printf(BOLD("\t\t\t\t   --     --     -- --       -  -       --            --  --       ----     -- --  -- --- --\n"));
  printf(BOLD("\t\t\t\t    --   --      -- --       -  -        --          --   --    ----        -- --  -- - - --\n"));
  printf(BOLD("\t\t\t\t     -- --       -- --       -  -          --      --     --       ----     -- --  -- - - --\n"));
  printf(BOLD("\t\t\t\t      --         -----       ----              --         --          ----  -----  ---- ----\n\n\n"));

}

//Função que aloca dinamicamente a matriz que será exibida para o jogador, o tabuleiro e a preenche com '-'
void preencherJogo(Jogo* jogo){
  //chama a função para alocar a matriz dinamicamente
  jogo->tabuleiro = alocarMatriz(jogo->linha, jogo->coluna);

  printf("\n");
  //percorre toda a matriz que será impressa para o jogador e preenche-a com '-'
  for(int i = 0; i < jogo->linha; i++){
    for(int j = 0; j < jogo->coluna; j++){
      jogo->tabuleiro[i][j] = '-';
    }
  }
}

//Função que alova dinamicamente a matriz que será exibida para o jogador e retoma para a situação salva pelo jogador anteriormente;
void retomarJogo(FILE *arq, Jogo *jogo){
  //chama a função paara alocar a matriz dinamicamente
  jogo->tabuleiro = alocarMatriz(jogo->linha, jogo->coluna);

  //Criar e ler as variáveis contendo a dimensão do jogo
  int linhaSituacao, colunaSituacao;
  fscanf(arq,"%d %d", &linhaSituacao, &colunaSituacao);
  //Cria e aloca dinamicamente uma matriz que receberá a situação em que o jogo estava quando foi salvo
  char **matrizSituacao = alocarMatriz(linhaSituacao, colunaSituacao);

  //preenche a matriz situação com o estado salvo do jogo anteriormente
  do{
    for(int i = 0; i < jogo->linha; i++){
      for(int j = 0; j < jogo->coluna; j++){
        fscanf(arq, " ");
        fscanf(arq, "%c", &matrizSituacao[i][j]);
      }
    }
  }while(!feof(arq));


  //verifica o estado de cada célula do jogo salvo (se foi aberta, marcada com bandeira ou não aberta)
  // e preenche a matriz que será impressa para o jogador
  for(int i = 0; i < jogo->linha; i++){
    for(int j = 0; j < jogo->coluna; j++){
      if(matrizSituacao[i][j] == '-')
        jogo->tabuleiro[i][j] = '-';
      else if(matrizSituacao[i][j] == 'x')
        jogo->tabuleiro[i][j] = '?';
      else if(matrizSituacao[i][j] == 'o')
        jogo->tabuleiro[i][j] = jogo->matrizEntrada[i][j];
    }
  }
}

//função que exibe ambas as matrizes (o tabuleiro e a matriz com o jogo resolvido), de acordo com o parâmetro passado na função
void mostrarJogo(Jogo* jogo, int escolha){
  //função que centraliza a impressão à tela (modo tela cheia)
  centralizar(jogo->coluna);
  //imprime o cabeçãrio do campo minado que é exibido na tela
  printf("   ");
  for(int i = 0; i < jogo->coluna; i++){
    printf("%3c",(char) i+65); //converte o inteiro para char para imprimir de A a Z
  }
  printf("\n");
  centralizar(jogo->coluna);
  printf("  "TAB_TL);
  for(int i = 0; i < jogo->coluna*3+2; i++){
    printf(TAB_HOR);
  }
  printf(""TAB_TR"\n");
    //Condição para saber se é para imprimir o jogo resolvido ou o tabuleiro (matriz com o progesso do jogador)
    // 1 para tabuleiro e 0 para matriz resolvida
    if(escolha){
    for(int i = 0; i < jogo->linha; i++){
      centralizar(jogo->coluna);
      printf("%c "TAB_VER,(char) i+65);
      for(int j = 0; j < jogo->coluna; j++){
          if(jogo->tabuleiro[i][j] == '0')
            printf(CYAN("%3c"), jogo->tabuleiro[i][j]);
          else if(jogo->tabuleiro[i][j] == '1')
            printf(BLUE("%3c"), jogo->tabuleiro[i][j]);
          else if(jogo->tabuleiro[i][j] == '2')
            printf(YELLOW("%3c"), jogo->tabuleiro[i][j]);
          else if(jogo->tabuleiro[i][j] == '3')
            printf(GREEN("%3c"), jogo->tabuleiro[i][j]);
          else if(jogo->tabuleiro[i][j] == '4')
            printf(MAGENTA("%3c"), jogo->tabuleiro[i][j]);
          else if(jogo->tabuleiro[i][j] == '5')
            printf(CYAN("%3c"), jogo->tabuleiro[i][j]);
          else if(jogo->tabuleiro[i][j] == '6')
            printf(CYAN("%3c"), jogo->tabuleiro[i][j]);
          else if(jogo->tabuleiro[i][j] == '7')
            printf(CYAN("%3c"), jogo->tabuleiro[i][j]);
          else if(jogo->tabuleiro[i][j] == '8')
            printf(CYAN("%3c"), jogo->tabuleiro[i][j]);
          else if(jogo->tabuleiro[i][j] == '?')
            printf(RED("%3c"), jogo->tabuleiro[i][j]);
          else printf(BOLD("%3c"), jogo->tabuleiro[i][j]);
      }
      printf("  "TAB_VER" %c",(char) i+65);
      printf("\n");
    }
  }else{
    for(int i = 0; i < jogo->linha; i++){
      centralizar(jogo->coluna);
      printf("%c "TAB_VER,(char) i+65);
      for(int j = 0; j < jogo->coluna; j++){
        if(jogo->matrizEntrada[i][j] == '0')
          printf(CYAN("%3c"), jogo->matrizEntrada[i][j]);
        else if(jogo->matrizEntrada[i][j] == '1')
          printf(BLUE("%3c"), jogo->matrizEntrada[i][j]);
        else if(jogo->matrizEntrada[i][j] == '2')
          printf(YELLOW("%3c"), jogo->matrizEntrada[i][j]);
        else if(jogo->matrizEntrada[i][j] == '3')
          printf(GREEN("%3c"), jogo->matrizEntrada[i][j]);
        else if(jogo->tabuleiro[i][j] == '4')
          printf(MAGENTA("%3c"), jogo->matrizEntrada[i][j]);
        else if(jogo->tabuleiro[i][j] == '5')
          printf(CYAN("%3c"), jogo->matrizEntrada[i][j]);
        else if(jogo->tabuleiro[i][j] == '6')
          printf(CYAN("%3c"), jogo->matrizEntrada[i][j]);
        else if(jogo->tabuleiro[i][j] == '7')
          printf(CYAN("%3c"), jogo->matrizEntrada[i][j]);
        else if(jogo->tabuleiro[i][j] == '8')
          printf(CYAN("%3c"), jogo->matrizEntrada[i][j]);
        else  printf(RED("%3c"), jogo->matrizEntrada[i][j]);
        }
      printf("  "TAB_VER" %c",(char) i+65);
      printf("\n");
    }
  }
  //Imprime o cabeçario da baixo do tabuleiro exibido na tela
  centralizar(jogo->coluna);
  printf("  "TAB_BL);
  for(int i = 0; i < jogo->coluna*3+2; i++){
    printf(TAB_HOR);
  }
  printf(""TAB_BR"\n");
  centralizar(jogo->coluna);
  printf("   ");
  for(int i = 0; i < jogo->coluna; i++){
    printf("%3c",(char) i+65);
  }
  printf("\n");
}

//Função que salva o jogo em dois arquivos (.jogo e .txt)
void salvarJogo(Jogo *jogo){
  char nome[50], nome2[50];//Variaveis para receber o nome do arquivo a ser salvo
  // centralizar(jogo->coluna);
  // printf(BLUE("Informe o nome do arquivo de saída: "));
  scanf("%s", nome);
  system("clear");
  //copia o nome do arquivo para a segunda variavel
  strcpy(nome2, nome);

  FILE *saida;
  //cria um arquivo com a extensão .jogo e salva nele o jogo original (resolvido)
  saida = fopen(strcat(nome, ".jogo"), "w");
  fprintf(saida, "%d %d\n\n", jogo->linha, jogo->coluna);
  for(int i = 0; i < jogo->linha; i++){
    for(int j = 0; j < jogo->coluna; j++){

      fprintf(saida, "%c ", jogo->matrizEntrada[i][j]);
    }
    fprintf(saida, "\n");
  }
  fclose(saida);

  //cria um arquivo com a extensão .txt e salva nele o estado atual do jogo
  saida = fopen(strcat(nome2, ".txt"), "w");
  fprintf(saida, "%d %d\n\n", jogo->linha, jogo->coluna);
  for(int i = 0; i < jogo->linha; i++){
    for(int j = 0; j < jogo->coluna; j++){
      if(jogo->tabuleiro[i][j] == '?')
        fprintf(saida, "x ");
      else if(jogo->tabuleiro[i][j] == '-')
        fprintf(saida, "- " );
      else
        fprintf(saida, "o ");
    }
    fprintf(saida, "\n");
  }
  fclose(saida);

}

//Função que abre a celula selecionada pelo jogador
int abrirCelula(Jogo* jogo, int linha, int coluna){
  if(jogo->matrizEntrada[linha][coluna] == 'x'){ //verifica se a célula selecionada é uma bomba e retorna 0 se for
    return 0;
  }else{
    if(jogo->matrizEntrada[linha][coluna] != '0'){//Verifica se a célula não é um 0, se for, apenas abre aquela célula
      jogo->tabuleiro[linha][coluna] = jogo->matrizEntrada[linha][coluna];
    }else{//Caso a célula selecionada seja '0', abre a célula e chama uma função para abrir as células adjacentes
      jogo->tabuleiro[linha][coluna] = jogo->matrizEntrada[linha][coluna];
      abrirZeros(jogo, linha, coluna);
    }
  }
  //retorna 1 caso tenham sido aberta célula que não fosse bomba
  return 1;
}

//Função que abre todos os 0 adjacentes ao escolhido pelo jogador
void abrirZeros(Jogo* jogo, int linha, int coluna){
  //Dois for para percorrer todas as 8 células adjacentes à posição da célula passada por parâmetro
  for(int i =  linha - 1; i <= linha + 1; i++){
    for(int j = coluna - 1; j <= coluna + 1; j++){
      //Verifica se a posição a ser analisada está dentro dos limites da matriz e se ainda não foi aberta
      if((i >= 0 && i < jogo->linha) && (j >= 0 && j < jogo->coluna) && !(i == linha && j == coluna) && jogo->tabuleiro[i][j] == '-'){
        if(jogo->matrizEntrada[i][j] != 'x'){//Caso verdadeiro, verifica se a célula não é uma boma
          if(jogo->matrizEntrada[i][j] != '0')//Caso verdadeiro, verifica se a célula não é outro 0. Se não for outro 0, apenas abre a celula dessa posição
            jogo->tabuleiro[i][j] = jogo->matrizEntrada[i][j];
          else{//Caso contrário, se for outro 0, abre a casa dessa posição e chama novamente a função para verificar as casas adjacentes à esta célula
            jogo->tabuleiro[i][j] = jogo->matrizEntrada[i][j];
            abrirZeros(jogo, i, j);
          }
        }
      }
    }
  }
}

//Função que seleciona a opção digitada pelo usuário e executa o que ela faz
void comando(Jogo* jogo){
  int bomba = quantidadeBomba(jogo); //Cria variável e chama a função para contabilizar a quantidade de bombas no jogo
  int l, c, sair = 0, erro = 0;
  char opcao[10], linha, coluna;

  //Do-While para solicitar o comando para o usuário enquanto ele não sair, resolver ou perder o jogo.
  do{
    menuDeOpcoes();
    printf("\n");
    mostrarJogo(jogo, 1);
    printf("\n");
    //Condição para verificar se algum erro deve ser exibido
    if(erro == 1){
      centralizar(16);
      printf(RED("Argumento inválido. Favor digitar o comando novamente!\n\n"));
      erro = 0;
    }else if(erro == 2){
      centralizar(16);
      printf(RED("Comando inválido. Favor digitar o comando novamente!\n\n"));
      erro = 0;
    }else if(erro == 3){
      centralizar(16);
      printf(RED("Favor escolher uma célula que não foi aberta!\n\n"));
      erro = 0;
    }
    centralizar(8);
    printf("Digite uma opção: ");
    scanf("%s", opcao);
    printf("\n");
    //Condições para verificar qual opção foi digitada pelo jogador
    if(!strcmp(opcao, "x")){
      scanf(" %c%c", &linha, &coluna);
      //converte a linha e coluna informada pelo jogador na forma de letra para números inteiros
      l = (int) linha - 65;
      c = (int) coluna - 65;
      //Verifica se a posição informada pelo jogador está dentro do limite da matriz
      if(l >= 0 && l < jogo->linha && c >=0 && c < jogo->coluna)
        //Condição para apenas marcar como bomba posições que ainda não foram abertas
        if(jogo->tabuleiro[l][c] == '-')
          jogo->tabuleiro[l][c] = '?';
        else
          erro = 3;
      else
        erro = 1;
      system("clear");
    }else{
      if(!strcmp(opcao, "o")){
        scanf(" %c%c", &linha, &coluna);
        l = (int) linha - 65;
        c = (int) coluna - 65;
        if(l >= 0 && l < jogo->linha && c >=0 && c < jogo->coluna){
          //Condição que chama a função de abrir a célula na posição informada
         // e se caso for uma bomba, chama a função para exibir o menu derrota e sai do jogo
          if(!abrirCelula(jogo, l, c)){
            system("clear");
            menuDerrota();
            mostrarJogo(jogo, 0);
            sair = 1;
          }
          else  sair = verificarVitoria(jogo, bomba);//Verifica se o jogador ganhou o jogo (abriu todas as células que poderiam ser abertas)
        }
        else erro = 1;
        if(!sair) system("clear");
      }else{
        if(!strcmp(opcao, "resolver")){//Opção resolver mostra o jogo e sai
          system("clear");
          mostrarJogo(jogo, 0);
          printf("\n");
          sair =  1;
        }else{
          if(!strcmp(opcao, "salvar")){//Opção salvar chama a funçao para salvar o jogo nas extensoes .jogo e .txt
            salvarJogo(jogo);
            system("clear");
            centralizar(8);
            printf(BOLD(BLUE("       Jogo salvo!\n\n\n")));
          }else{
            if(!strcmp(opcao, "sair")){
              sair = 1;
            }else{
              erro = 2;
              system("clear");
            }
          }
        }
      }
    }

  }while(!sair);
}

//Função que conta a quantidade de bombas existente no jogo
int quantidadeBomba(Jogo *jogo){
  int bombas = 0;
  //Percorre todas a matriz e soma 1 à variável bombas para toda bomba encontrada
  for(int i = 0; i < jogo->linha; i++){
    for(int j = 0; j < jogo->coluna; j++){
      if(jogo->matrizEntrada[i][j] == 'x')
        bombas++;
    }
  }
  return bombas;
}

//Função que verifica se o usuário ganhou o jogo
int verificarVitoria(Jogo *jogo, int bomba){
  //Percorre toda a matriz e verifica se o número de células não abertas somado ao número de células marcadas
  // como bomba é igual ao número total de bombas, caso seja, o jogador venceu o jogo
  int aux = 0;
  for(int i = 0; i < jogo->linha; i++){
    for(int j = 0; j < jogo->coluna; j++){
      if(jogo->tabuleiro[i][j] == '?' || jogo->tabuleiro[i][j] == '-')
        aux++;
    }
  }
  if(aux == bomba){
    system("clear");
    menuVitoria();
    printf("\n");
    mostrarJogo(jogo, 0);
    return 1;
  }else
    return 0;

}

//Função que seleciona a dificuldade do jogo aleatoria (ou seja, seleicona a diemnsão da matriz)
void dificuldade(Jogo* jogo){
  char escolha;
  printf("Escolha a dificuldade do jogo: \n");
  printf("1 - Fácil\n");
  printf("2 - Médio\n");
  printf("3 - Difícil\n");
  do{
    scanf("%c", &escolha);
      switch (escolha) {
        case '1':
          jogo->linha = 9;
          jogo->coluna = 9;
          break;
        case '2':
          jogo->linha = 13;
          jogo->coluna = 10;
          break;
        case '3':
          jogo->linha = 18;
          jogo->coluna = 18;
          break;
        default:
          printf("Opção Inválida. Escolha novamente: ");
          scanf(" ");
          escolha = 0;
        }
  }while(!escolha);
  system("clear");
}

//Função para centralizar a impressão na tela no modo cheio
void centralizar(int coluna){
    int tamanho = (46-coluna)/2;
    for (int i=0; i< tamanho; i++)
        printf("   ");

}
