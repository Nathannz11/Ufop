//Aluno: Nathann Zini dos Reis
//Matricula: 19.2.4007

#include "functional_tests.hpp"

#include "../../src/model.hpp"
#include "../../src/system.hpp"
#include "../../src/flow.hpp"

int main(){

    exponentialFuncionalTest();
    logisticalFuncionalTest();
    complexFuncionalTest();

    return 0;
}