//Aluno: Nathann Zini dos Reis
//Matricula: 19.2.4007

#ifndef FLOW_HPP
#define FLOW_HPP

#include "system.hpp"
#include <string>

using namespace std;

class Flow{

    string nome;
    System *origem;
    System *destino;
    
    public:
    

    Flow(string nome = "", System* = NULL, System* = NULL  );

    virtual double run() = 0;


    //getters & Setters
    string getNome() const;
    void setNome(string nome);
    System* getOrigem() const;
    void setOrigem(System* origem);
    System* getDestino() const;
    void setDestino(System* destino);
     

    //Limpar Origem e Destino

    void limparOrigem();
    void limparDestino();

    Flow& operator=(const Flow& flow);
};

//Cria flow específico para diferenciar cada execução
class FlowExponencial : public Flow{
    public:
        FlowExponencial(string nome = "", System* origem = NULL, System* destino = NULL): Flow(nome, origem, destino){}

        double run(){
            return 0.01 * getOrigem()->getValorInicial();
        }
};


class FlowLogistico : public Flow{
    public:
        FlowLogistico(string nome, System* origem, System* destino): Flow(nome, origem, destino){}

        double run(){
            return 0.01 * getDestino()->getValorInicial() * (1 - getDestino()->getValorInicial() / 70);
        }
};

#endif
