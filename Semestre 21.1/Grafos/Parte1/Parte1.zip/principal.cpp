#include "BFS.hpp"

using namespace std;


int main(){
    inicioBuscaLargura();    
    return 0;
}