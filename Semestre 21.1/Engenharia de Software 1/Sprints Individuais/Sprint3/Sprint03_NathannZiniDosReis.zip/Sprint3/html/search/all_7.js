var searchData=
[
  ['nome_0',['nome',['../class_system.html#a0df121c718a4da7b5e0fec4f8701b4bf',1,'System']]]
];
