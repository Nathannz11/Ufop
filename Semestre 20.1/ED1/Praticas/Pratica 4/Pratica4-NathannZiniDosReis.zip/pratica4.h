//Nathann Zini dos Reis 19.2.4007


#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int menu();

int sequenciaFibonacci(int n, int *qtdRepeticao);

void vetorInverso(int n, int* vet);

void grau9(long long int n, int *grau, int tamanho, int *soma);

void buscaBinaria(int* vet, int tamanho, int *indice, int k, int metade);