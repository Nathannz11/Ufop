//Aluno: Nathann Zini dos Reis
//Matricula: 19.2.4007

#include <iostream>

#include "../../src/system.hpp"
#include "../../src/flow.hpp"
#include "../../src/model.hpp"

#include "functional_tests.hpp"

using namespace std;


void exponentialFuncionalTest(){
    cout << "TESTE 1 - modelo simples com equacao exponencial" << endl;

    
    System* pop1 = new System("Populacao 1", 100.0);
    System* pop2 = new System("Populacao 2", 0.0);
    FlowExponencial* flowExponencial = new FlowExponencial("Crescimento ilimitado", pop1, pop2);
    Model* modelExponencial = new Model("Modelo Exponencial");
    

    modelExponencial->add(pop1);
    modelExponencial->add(pop2);
    modelExponencial->add(flowExponencial);


    modelExponencial->run(0, 100);

    delete (&modelExponencial);
    std :: cout << "OK" << endl;
}

// Function for logistical functional test.
void logisticalFuncionalTest(){
    cout << "TESTE 2 - modelo simples com equacao logistica" << endl;
    
    System* p1 = new System("Populacao 1", 100);
    System* p2 = new System("Populacao 2", 10);
    FlowLogistico* flowLogistico = new FlowLogistico("Crescimento limitado", p1, p2);
    Model* modeloLogistico = new Model("Modelo Logistico");
    
    modeloLogistico->add(p1);
    modeloLogistico->add(p2);
    modeloLogistico->add(flowLogistico);

    modeloLogistico->run(0, 100);

    delete(modeloLogistico);
    cout << "OK" << endl;
}

void complexFuncionalTest(){
    cout << "TESTE 3 - modelo complexo com equacoes exponenciais e logistica" << endl;

    System* q1 = new System("Populaçao 1", 100.0);
    System* q2 = new System("Populaçao 2", 0.0);
    System* q3 = new System("População 3", 100.0);
    System* q4 = new System("População 4", 0.0);
    System* q5 = new System("População 5", 0.0);

    FlowExponencial* f = new FlowExponencial("Flow Exponencial F", q1, q2);
    FlowLogistico* g = new FlowLogistico("Flow Logistico g", q1, q3);
    FlowExponencial* r = new FlowExponencial("Flow Exponencial r", q2, q5);
    FlowExponencial* t = new FlowExponencial("Flow Exponencial t", q2, q3);
    FlowExponencial* u = new FlowExponencial("Flow Exponencial u", q3, q4);
    FlowExponencial* v = new FlowExponencial("Flow Exponencial v", q4, q1);

    Model* model = new Model("Modelo complexo");
    model->add(q1);
    model->add(q2);
    model->add(q3);
    model->add(q4);
    model->add(q5);
    model->add(f);
    model->add(g);
    model->add(r);
    model->add(t);
    model->add(u);
    model->add(v);
    model->run(0,100);

    cout << "OK" << endl;

}