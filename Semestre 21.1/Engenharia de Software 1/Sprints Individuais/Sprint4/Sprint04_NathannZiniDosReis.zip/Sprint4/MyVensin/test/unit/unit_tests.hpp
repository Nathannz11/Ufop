//Aluno: Nathann Zini Dos Reis
//Matricula: 19.2.4007

#ifndef UNIT_TESTS
#define UNIT_TESTS


/*!
    prototipo de funcao para a classe System' "+" operador global unit test.
*/
void unit_test_global_sumOperator();

/*!
    prototipo de funcao para a classe System' "-" operador global unit test.
*/
void unit_test_global_minusOperator();

/*!
    prototipo de funcao para a classe System' "*" operador global unit test.
*/
void unit_test_global_timesOperator();

/*!
    prototipo de funcao para a classe System' "/" operador global unit test.
*/
void unit_test_global_divisionOperator();

/*!
    Prototipo de funcao que executa todos os unit tests globais.
*/
void run_unit_tests_globals();

    
#endif