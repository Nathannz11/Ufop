var indexSectionsWithContent =
{
  0: "abcdefghlmnoprsuv~",
  1: "bfhms",
  2: "fhmsu",
  3: "abcdefghlmorsu~",
  4: "npv",
  5: "fs",
  6: "mu",
  7: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related",
  7: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de Tipos",
  6: "Amigas",
  7: "Definições e Macros"
};

