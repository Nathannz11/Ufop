# React app starter project (from scratch)

A lightweight starter project without using the create-react-app CLI
