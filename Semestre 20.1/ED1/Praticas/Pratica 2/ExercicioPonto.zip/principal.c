//
//  principal.c
//  Ponto
//
//

#include <stdio.h>
#include "ponto.h"

int main(){
    
    Ponto* p1 = pto_cria(2.0,4.0);
    //ERRO Ponto* p2 = (Ponto*) malloc(sizeof(Ponto));
    //ERRO   Ponto p2;
    
    return 0;
}
