//Nathann Zini dos Reis 19.2.4007 BCC201-31

#include <stdio.h>
#include "biblioteca.h"

int main(int argc, char *argv[]){
  system("clear");
  //Verificando se há arquivo de entrada
  if(argc == 3){
    verificarArquivoDeEntrada(argc, argv);

    //Criando a matriz do tabuleiro
    Jogo jogo;

    //Criando uma variável para o arquivo de entrada
    FILE *arq, *arqSituacao;

    //Abrindo os arquivos de entrada
    arq = fopen(argv[1], "r");
    arqSituacao = fopen(argv[2], "r");

    lerMatriz(arq, &jogo);

    retomarJogo(arqSituacao, &jogo);

    comando(&jogo);

    liberarMemoria(&jogo);
    fclose(arq);
    fclose(arqSituacao);
  }
  else{
     if(argc == 2){
      //Criando a matriz do tabuleiro
      Jogo jogo;

      //Criando uma variável para o arquivo de entrada
      FILE *arq;

      //Abrindo arquivo de entrada
      arq = fopen(argv[1], "r");

      lerMatriz(arq, &jogo);

      preencherJogo(&jogo);

      comando(&jogo);

      liberarMemoria(&jogo);
      fclose(arq);
    }else{
      //Criando a matriz do tabuleiro
      Jogo jogo;

      dificuldade(&jogo);

      gerarMatriz(&jogo);

      preencherJogo(&jogo);

      comando(&jogo);

      liberarMemoria(&jogo);
    }
  }
  return 0;
}
