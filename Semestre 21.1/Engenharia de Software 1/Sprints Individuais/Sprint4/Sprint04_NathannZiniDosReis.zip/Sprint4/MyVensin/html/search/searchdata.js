var indexSectionsWithContent =
{
  0: "abcefglmnorsuv~",
  1: "fmsu",
  2: "fmsu",
  3: "abcefglmorsu~",
  4: "nv",
  5: "fs",
  6: "mu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de Tipos",
  6: "Amigas"
};

