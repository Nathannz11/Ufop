//Nathann Zini dos Reis 19.2.4007 BCC201-31

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct{
  char** matrizEntrada;
  char** tabuleiro;
  int linha;
  int coluna;
}Jogo;

//Função para verificar se os arquivos foram indormados na ordem certa ao retomar um jogo salvo
void verificarArquivoDeEntrada(int argc, char *argv[]);

//Aloca dinamicamente a matriz
char** alocarMatriz(int l, int c);

//Desaloca a matriz dinâmica
void liberarMemoria(Jogo* jogo);

//Lê a matriz no arquivo de entrada
void lerMatriz(FILE *arq, Jogo* jogo);

//Inicializa o tabuleiro com '-'
void preencherJogo(Jogo* jogo);

//Retoma o jogo anteriormente salvo pelo usuário
void retomarJogo(FILE *arq, Jogo *jogo);

//Gera uma matriz aleatório
void gerarMatriz(Jogo* jogo);

//Verifica a quantidade de bombas
int quantidadeBomba(Jogo *jogo);

//lê o comando digitado e retorna um inteiro
void comando(Jogo* jogo);

//Verifica se o Jogo acabou com vitória;
int verificarVitoria(Jogo *jogo, int bomba);

//Abre a célula informada pelo usuário
int abrirCelula(Jogo* jogo, int linha, int coluna);

//Abre todas as células até as bombas
void abrirZeros(Jogo* jogo, int linha, int coluna);

//Seleciona a dificuldade do jogo aleatório
void dificuldade(Jogo* jogo);

//Exibe o jogo
void mostrarJogo(Jogo* jogo, int escolha);

//Salva o jogo;
void salvarJogo(Jogo* jogo);

//Exibe o menu inicial
void menuDeOpcoes();

void menuDerrota();

void menuVitoria();

void centralizar(int coluna);


// cores e formato de texto
#define ANSI_RESET            "\x1b[0m"  // desativa os efeitos anteriores
#define ANSI_BOLD             "\x1b[1m"  // coloca o texto em negrito
#define ANSI_COLOR_BLACK      "\x1b[30m"
#define ANSI_COLOR_RED        "\x1b[31m"
#define ANSI_COLOR_GREEN      "\x1b[32m"
#define ANSI_COLOR_YELLOW     "\x1b[33m"
#define ANSI_COLOR_BLUE       "\x1b[34m"
#define ANSI_COLOR_MAGENTA    "\x1b[35m"
#define ANSI_COLOR_CYAN       "\x1b[36m"
#define ANSI_COLOR_WHITE      "\x1b[37m"
#define ANSI_BG_COLOR_BLACK   "\x1b[40m"
#define ANSI_BG_COLOR_RED     "\x1b[41m"
#define ANSI_BG_COLOR_GREEN   "\x1b[42m"
#define ANSI_BG_COLOR_YELLOW  "\x1b[43m"
#define ANSI_BG_COLOR_BLUE    "\x1b[44m"
#define ANSI_BG_COLOR_MAGENTA "\x1b[45m"
#define ANSI_BG_COLOR_CYAN    "\x1b[46m"
#define ANSI_BG_COLOR_WHITE   "\x1b[47m"

// macros para facilitar o uso
#define BOLD(string)       ANSI_BOLD             string ANSI_RESET
#define BLACK(string)      ANSI_COLOR_BLACK      string ANSI_RESET
#define BLUE(string)       ANSI_COLOR_BLUE       string ANSI_RESET
#define RED(string)        ANSI_COLOR_RED        string ANSI_RESET
#define GREEN(string)      ANSI_COLOR_GREEN      string ANSI_RESET
#define YELLOW(string)     ANSI_COLOR_YELLOW     string ANSI_RESET
#define BLUE(string)       ANSI_COLOR_BLUE       string ANSI_RESET
#define MAGENTA(string)    ANSI_COLOR_MAGENTA    string ANSI_RESET
#define CYAN(string)       ANSI_COLOR_CYAN       string ANSI_RESET
#define WHITE(string)      ANSI_COLOR_WHITE      string ANSI_RESET
#define BG_BLACK(string)   ANSI_BG_COLOR_BLACK   string ANSI_RESET
#define BG_BLUE(string)    ANSI_BG_COLOR_BLUE    string ANSI_RESET
#define BG_RED(string)     ANSI_BG_COLOR_RED     string ANSI_RESET
#define BG_GREEN(string)   ANSI_BG_COLOR_GREEN   string ANSI_RESET
#define BG_YELLOW(string)  ANSI_BG_COLOR_YELLOW  string ANSI_RESET
#define BG_BLUE(string)    ANSI_BG_COLOR_BLUE    string ANSI_RESET
#define BG_MAGENTA(string) ANSI_BG_COLOR_MAGENTA string ANSI_RESET
#define BG_CYAN(string)    ANSI_BG_COLOR_CYAN    string ANSI_RESET
#define BG_WHITE(string)   ANSI_BG_COLOR_WHITE   string ANSI_RESET

// caracteres uteis para tabelas
#define TAB_HOR "\u2501" // ━ (horizontal)
#define TAB_VER "\u2503" // ┃ (vertical)
#define TAB_TL  "\u250F" // ┏ (top-left)
#define TAB_ML  "\u2523" // ┣ (middle-left)
#define TAB_BL  "\u2517" // ┗ (bottom-left)
#define TAB_TJ  "\u2533" // ┳ (top-join)
#define TAB_MJ  "\u254B" // ╋ (middle-join)
#define TAB_BJ  "\u253B" // ┻ (bottom-join)
#define TAB_TR  "\u2513" // ┓ (top-right)
#define TAB_MR  "\u252B" // ┫ (middle-right)
#define TAB_BR  "\u251B" // ┛ (bottom-right)
