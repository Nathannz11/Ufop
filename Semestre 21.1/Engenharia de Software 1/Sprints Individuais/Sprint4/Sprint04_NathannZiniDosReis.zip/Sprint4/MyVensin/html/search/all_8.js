var searchData=
[
  ['nome_0',['nome',['../class_system_impl.html#a1869991cb9d112f1746c5bb278ab173c',1,'SystemImpl']]]
];
