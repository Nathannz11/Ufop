#ifndef geradorArq_h
#define geradorArq_h

void geradorArq(char *filename, int maxtam, int op);

#endif