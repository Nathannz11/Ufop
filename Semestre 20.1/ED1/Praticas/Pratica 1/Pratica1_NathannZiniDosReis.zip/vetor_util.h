

int buscaSequencial (int *vetor , int n, int elemento);

int buscaBinaria (int *vetor , int n, int elemento);

int* intercalaVetoresOrdenados (int* nums1 , int nums1Tam , int* nums2 , int nums2Tam);

int comparaVetores (int* nums1 , int* nums2 , int nums1Tam , int nums2Tam);