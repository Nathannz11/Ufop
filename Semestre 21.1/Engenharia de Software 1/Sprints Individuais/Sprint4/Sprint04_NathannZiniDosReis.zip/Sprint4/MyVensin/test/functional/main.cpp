//Aluno: Nathann Zini dos Reis
//Matricula: 19.2.4007

#include "functional_tests.hpp"

int main(){

    exponentialFuncionalTest();
    logisticalFuncionalTest();
    complexFuncionalTest();

    return 0;
}