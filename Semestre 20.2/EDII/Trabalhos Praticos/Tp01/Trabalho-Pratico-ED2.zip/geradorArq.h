#ifndef geradorArq_h
#define geradorArq_h

void geradorArq(int maxtam, int op);

#endif