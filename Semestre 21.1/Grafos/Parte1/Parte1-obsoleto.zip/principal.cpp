#include "BFS.hpp"

using namespace std;


int main(){
    Bfs grafo;

    int n, m, dir, vInicial;

    cin >> n;
    cin >> m;
    cin >> dir;
    cin >> vInicial;

    //adiciona vertices
    for(int i = 1; i <=n; i++){
        Vertice aux;
        aux.numero = i;
        aux.visitado = false;
        grafo.vertices.push_back(aux);
    }

    //list<list <Vertice>> adj[n];
    list<Vertice> *adj = new list<Vertice>[n];


    //adiciona arestas
    for(int i = 0; i < m; i++){
        Aresta aux;
        int nmrOrigem;
        cin >> nmrOrigem;
        aux.origem = &grafo.vertices[nmrOrigem - 1];
        int nmrDestino;
        cin >> nmrDestino;
        aux.destino = &grafo.vertices[nmrDestino - 1];

        cin >> aux.peso;
        aux.visitado = false;

        grafo.arestas.push_back(aux);

        //adicionando adjacencia

        adj[aux.origem->numero - 1].push_back(*aux.destino);

        if(!dir)
            adj[aux.destino->numero - 1].push_back(*aux.origem);
    }

    queue<int> listaDeEspera;

    vector<int> descobertos;

    //procurar a partir do inicial


    listaDeEspera.push(vInicial);
    grafo.vertices[vInicial-1].visitado = true;
    descobertos.push_back(vInicial);

    while(!listaDeEspera.empty()){
        int u = listaDeEspera.front();
        listaDeEspera.pop();
        for(Vertice &vertice : adj[u-1]){
            if(grafo.vertices[vertice.numero - 1].visitado == false){
                listaDeEspera.push(vertice.numero);
                descobertos.push_back(vertice.numero);
                grafo.vertices[vertice.numero - 1].visitado = true;
            }
        }
    }

    //imprimir vertices na ordem em que foram visitados
    
    for(auto &item : descobertos){
        cout << item << endl;
    }

    return 0;
}