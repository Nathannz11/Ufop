var searchData=
[
  ['add_0',['add',['../class_model.html#afde6c25ab942f2eec7aedeaf8eec53fd',1,'Model::add(System *system)=0'],['../class_model.html#ab7df81041f62f049cfc6e4d50dcaf721',1,'Model::add(Flow *flow)=0'],['../class_model_body.html#a792d303ccb76e2c6755d17a1d8f51d15',1,'ModelBody::add(System *system)'],['../class_model_body.html#aa970c15679b82c7d265f04f5bbf737e4',1,'ModelBody::add(Flow *flow)'],['../class_model_handle.html#acf6ea36ccd2ee6d375c988bc71dcfcdd',1,'ModelHandle::add(System *system)'],['../class_model_handle.html#a1c2fe71daa814c09442b735a81f9ba53',1,'ModelHandle::add(Flow *flow)']]],
  ['attach_1',['attach',['../class_body.html#a5d53322c76a6952d096cb7564ac86db1',1,'Body']]]
];
