var searchData=
[
  ['add_0',['add',['../class_model.html#afde6c25ab942f2eec7aedeaf8eec53fd',1,'Model::add(System *system)=0'],['../class_model.html#ab7df81041f62f049cfc6e4d50dcaf721',1,'Model::add(Flow *flow)=0'],['../class_model_impl.html#a38c4b4ccdc8cc7a426063a747fd960ec',1,'ModelImpl::add(System *system)'],['../class_model_impl.html#a3b71fb4f8f2b4933104f03a91138a758',1,'ModelImpl::add(Flow *flow)']]]
];
