//Aluno: Nathann Zini dos Reis
//Matricula: 19.2.4007

#ifndef SYSTEM_HPP
#define SYSTEM_HPP

#include <iostream>

using namespace std;

class System{

    string nome;
    double valorInicial;

    public:
    
    System(string nome = "", double valorIni = 0.0) ;

    string getNome() const;
    void setNome(string nome);

    double getValorInicial() const;

    void setValorInicial(double valorInicial);

    System& operator=(const System& sistema);
     
};

#endif
