//Aluno: Nathann Zini dos Reis
//Matricula: 19.2.4007

#ifndef MODEL_HPP
#define MODEL_HPP

#include "flow.hpp"
#include <vector>

using namespace std;


class Model{
    private:

    string nome;
    vector<System*> sistemas;
    vector<Flow*> flows;
    

    public:
    

    Model(string nome = "" );

    //Getters & Setters
    string getNome() const ;
    void setNome(string nome);

    //Adicionando Sistema ou Flow ao model
    void run(double inicio = 0.0, double fim = 0.0);
    
    void add(System* system);
    void add(Flow* flow);

    void remove(System* sistema);
    void remove(Flow* flow);

    Model& operator=(const Model& model);
};

#endif
